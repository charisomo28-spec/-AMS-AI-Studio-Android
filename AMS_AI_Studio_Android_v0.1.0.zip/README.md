# AMS AI Studio Android — foundation v0.1.0

This is an **offline-first working foundation**, not the full AMS desktop engine stack. It includes a dark mobile interface, locally persistent photo gallery (IndexedDB), selection and deletion, real on-device brightness/contrast/saturation/warmth adjustments, JPG export, edit modes AUTO/BRIGHT/CLEAN/INTENSE, basic chat interface with honest engine status, diagnostics, and the supplied AMS Photography logo.

**Not included:** FLUX, a local LLM, AI skin retouch, photo classification, reliable offline speech recognition, or parity with the PC engines. Browser speech recognition may require an external service; do not use it for sensitive material unless you verify the device's implementation.

## Build an APK using only your phone

1. On your Android phone, create a **private GitHub repository** and upload the contents of this project ZIP to its root (including the hidden `.github` folder). GitHub's web UI may not support bulk folder uploads easily on mobile; a Git client that supports ZIP extraction and folder uploads can help.
2. Go to the repository **Actions** tab, select **Build AMS Android APK**, and tap **Run workflow**. The workflow also runs automatically on pushes to `main`.
3. Once the workflow succeeds, open the workflow run, download the artifact named **AMS-AI-Studio-debug-APK** to your phone, extract it, and install `app-debug.apk` (grant install-from-this-source permission if Android asks).
4. The debug APK is for testing, not Play Store release. Build must pass on GitHub before the APK exists.

To test without an APK, serve `www` using a local HTTP server on your phone and open its URL in Chrome. Opening `index.html` as a `file://` URL may break IndexedDB or service worker support.

## Architecture

This v0.1.0 uses HTML/CSS/JS bundled in an Android Capacitor WebView. The photo editor is real but limited to color adjustments. The source is organized so future native Android ML backends can be integrated without misrepresenting capabilities.

## Important

The original photos are not modified. Imports create local copies in IndexedDB; exporting generates a new JPG. Deleting app storage removes these imported copies. Large imports may exceed browser storage quotas; test with a few images first. The supplied logo is used as the web icon; Android launcher icon customization can be added later.
